from . import pos_equipment
from . import payment_method
from . import pos_api_config
from . import pos_seriales
from . import transaction_response
from . import account_move
from . import res_config_settings
from . import pos_order
    
